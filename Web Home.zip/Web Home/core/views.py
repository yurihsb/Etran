from django.shortcuts import render
from .models import Offering

def home(request):
    offerings = Offering.objects.all()
    return render(request, 'index.html', {'offerings': offerings})