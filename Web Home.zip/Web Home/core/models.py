from django.db import models

class Offering(models.Model):
    title = models.CharField(max_length=100)
    icon_name = models.CharField(max_length=50)  # Ex: 'bolt', 'globe', 'shield'
    description = models.TextField()

    def __str__(self):
        return self.title