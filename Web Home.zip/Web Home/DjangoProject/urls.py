from django.contrib import admin
from django.urls import path
from core.views import home  # Importamos a função home que você criou no views.py

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),  # O caminho vazio '' significa a página inicial
]